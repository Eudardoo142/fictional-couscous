import React from 'react'
import './App.css'

const images = [
  'https://via.placeholder.com/800x400?text=Look+1',
  'https://via.placeholder.com/800x400?text=Look+2',
  'https://via.placeholder.com/800x400?text=Look+3'
]

export default function App() {
  const [index, setIndex] = React.useState(0)

  React.useEffect(() => {
    const interval = setInterval(() => {
      setIndex((i) => (i + 1) % images.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="container">
      <h1>Kalyma</h1>
      <p>Moda Feminina com estilo e identidade</p>
      <div className="carousel">
        <img src={images[index]} alt="Look Kalyma" />
      </div>
    </div>
  )
}
